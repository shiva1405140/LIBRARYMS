from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
## implemention of api endponts 


## get,post,put,delete

## class Views
## U just define class extract prop of pc

from rest_framework import viewsets
from django.shortcuts import render
from .models import Books
from .serializers import BooksSerializers

# This handles the API logic
class BookViewSet(viewsets.ModelViewSet):
    queryset = Books.objects.all()
    serializer_class = BooksSerializers
    
# function view 
# This renders your actual HTML UI
def library_ui(request):
    return render(request, 'books/indexA.html')


# template(inside app folder)/app_name/index.html
# static/