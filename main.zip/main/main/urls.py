from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from books.views import BookViewSet, library_ui

router = DefaultRouter()
router.register(r'api/books', BookViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', library_ui), # The UI home page
    path('', include(router.urls)), # The API endpoints
]

#localhost/admin
# localhost/ = library_ui
# localhost/api/books/1/ = BookViewSEt